package org.schambon.loadsimrunner;

public interface Generator {
    Object generate();
}
