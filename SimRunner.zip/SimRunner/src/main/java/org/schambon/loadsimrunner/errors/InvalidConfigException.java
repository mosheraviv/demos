package org.schambon.loadsimrunner.errors;

public class InvalidConfigException extends RuntimeException {

    public InvalidConfigException(String string) {
        super(string);
    }
    
}
